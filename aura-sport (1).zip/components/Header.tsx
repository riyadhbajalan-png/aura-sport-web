
import React from 'react';
import { AppView } from '../types';

const OfficialAuraLogo = ({ size = "normal" }: { size?: "normal" | "large" }) => {
  const isLarge = size === "large";
  return (
    <div className={`flex flex-col items-center group cursor-pointer transition-all duration-500 ${isLarge ? 'scale-150' : 'hover:scale-110'}`}>
      <div className="relative flex items-center justify-center" style={{ width: isLarge ? '180px' : '100px', height: isLarge ? '140px' : '80px' }}>
        
        {/* Neon Rings Layer - Matching User Image perfectly */}
        <div className="absolute inset-0 flex items-center justify-center">
          <svg viewBox="0 0 200 200" className="w-full h-full overflow-visible drop-shadow-[0_0_15px_rgba(0,209,255,0.8)]">
            <defs>
              <linearGradient id="neonGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#00d1ff" />
                <stop offset="50%" stopColor="#0077ff" />
                <stop offset="100%" stopColor="#00d1ff" />
              </linearGradient>
              <filter id="blurFilter">
                <feGaussianBlur stdDeviation="3" />
              </filter>
            </defs>
            
            {/* Primary Glowing Rings */}
            <ellipse cx="100" cy="100" rx="90" ry="25" fill="none" stroke="url(#neonGradient)" strokeWidth="3" transform="rotate(-20 100 100)" className="opacity-90" />
            <ellipse cx="100" cy="100" rx="85" ry="22" fill="none" stroke="#00f2ff" strokeWidth="1" transform="rotate(-15 100 100)" filter="url(#blurFilter)" />
            <ellipse cx="100" cy="100" rx="75" ry="20" fill="none" stroke="url(#neonGradient)" strokeWidth="2" transform="rotate(10 100 100)" className="opacity-70" />
            
            {/* Light Sparks/Stars around the rings */}
            <circle cx="160" cy="60" r="1.5" fill="white" className="animate-pulse" />
            <circle cx="40" cy="140" r="1" fill="white" className="animate-pulse" />
            <circle cx="180" cy="100" r="2" fill="#00d1ff" />
          </svg>
        </div>

        {/* 3D Soccer Ball with realistic shading */}
        <div className="relative z-10 w-1/2 h-1/2">
          <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-2xl">
            <defs>
              <radialGradient id="ballShadow" cx="50%" cy="50%" r="50%">
                <stop offset="70%" stopColor="white" />
                <stop offset="100%" stopColor="#cbd5e1" />
              </radialGradient>
            </defs>
            <circle cx="50" cy="50" r="48" fill="url(#ballShadow)" />
            <path d="M50 2 L65 25 L50 48 L35 25 Z M65 25 L95 35 L88 70 L65 60 L50 48 Z M35 25 L5 35 L12 70 L35 60 L50 48 Z M50 98 L70 75 L50 60 L30 75 Z M88 70 L92 75 L75 95 L70 75 L65 60 Z M12 70 L8 75 L25 95 L30 75 L35 60 Z" fill="#0f172a" />
            <circle cx="50" cy="50" r="48" fill="none" stroke="#1e293b" strokeWidth="1" />
            {/* Glossy reflection */}
            <path d="M30 25 Q40 15 55 20" stroke="white" strokeWidth="2" strokeLinecap="round" opacity="0.4" />
          </svg>
        </div>
      </div>

      {/* Typography - Precision Matching the user's logo text */}
      <div className="flex flex-col items-center -mt-2">
        <h1 className="text-white font-black italic tracking-tighter leading-none select-none" style={{ fontSize: isLarge ? '48px' : '28px' }}>
          AURA
        </h1>
        <div className="flex items-center gap-2 w-full mt-1">
          <div className="h-[2px] flex-grow bg-gradient-to-r from-transparent to-white/60"></div>
          <span className="text-white font-black uppercase tracking-[0.4em] select-none" style={{ fontSize: isLarge ? '14px' : '9px' }}>
            SPORT
          </span>
          <div className="h-[2px] flex-grow bg-gradient-to-l from-transparent to-white/60"></div>
        </div>
      </div>
    </div>
  );
};

interface HeaderProps {
  activeView: AppView;
  onViewChange: (view: AppView) => void;
}

export const Header: React.FC<HeaderProps> = ({ activeView, onViewChange }) => {
  return (
    <header className="bg-gray-950/95 backdrop-blur-3xl text-white sticky top-0 z-50 border-b border-white/10 shadow-[0_10px_50px_rgba(0,0,0,0.5)]">
      <div className="container mx-auto px-6 h-28 flex justify-between items-center">
        <div onClick={() => onViewChange('home')}>
          <OfficialAuraLogo />
        </div>
        
        <nav className="hidden md:flex items-center gap-10">
          <button 
            onClick={() => onViewChange('home')}
            className={`text-[11px] font-black tracking-widest transition-all uppercase ${activeView === 'home' ? 'text-blue-400 border-b-2 border-blue-400 pb-1' : 'text-gray-500 hover:text-white'}`}
          >
            الرئيسية
          </button>
          <button 
            onClick={() => onViewChange('leagues')}
            className={`text-[11px] font-black tracking-widest transition-all uppercase ${activeView === 'leagues' ? 'text-blue-400 border-b-2 border-blue-400 pb-1' : 'text-gray-500 hover:text-white'}`}
          >
            الدوريات
          </button>
          <button 
            onClick={() => onViewChange('mercato')}
            className={`text-[11px] font-black tracking-widest transition-all uppercase ${activeView === 'mercato' ? 'text-blue-400 border-b-2 border-blue-400 pb-1' : 'text-gray-500 hover:text-white'}`}
          >
            الميركاتو
          </button>
          <div className="h-6 w-[1px] bg-white/10 mx-2"></div>
          <div className="flex items-center gap-3 bg-blue-500/10 px-5 py-2 rounded-xl border border-blue-400/20 shadow-lg">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-400"></span>
            </span>
            <span className="text-[9px] font-black text-blue-300 uppercase tracking-widest">Aura AI Pulse</span>
          </div>
        </nav>
      </div>
    </header>
  );
};
