
import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { Ticker } from './components/Ticker';
import { FilterBar } from './components/FilterBar';
import { NewsCard } from './components/NewsCard';
import { NewsSkeleton } from './components/Skeleton';
import { GeminiSummary } from './components/GeminiSummary';
import { LeagueSection } from './components/LeagueSection';
import { NewsDetail } from './components/NewsDetail';
import { MercatoView } from './components/MercatoView';
import { fetchNews, MOCK_SCORES } from './services/newsService';
import { NewsItem, Language, AppState, AppView } from './types';

// نستخدم نفس مكون الشعار لضمان التطابق
const OfficialAuraLogo = ({ size = "normal" }: { size?: "normal" | "large" }) => {
  const isLarge = size === "large";
  return (
    <div className={`flex flex-col items-center group cursor-default transition-all duration-500`}>
      <div className="relative flex items-center justify-center" style={{ width: isLarge ? '200px' : '100px', height: isLarge ? '160px' : '80px' }}>
        <div className="absolute inset-0 flex items-center justify-center">
          <svg viewBox="0 0 200 200" className="w-full h-full overflow-visible drop-shadow-[0_0_25px_rgba(0,209,255,0.6)]">
            <ellipse cx="100" cy="100" rx="90" ry="25" fill="none" stroke="#00d1ff" strokeWidth="3" transform="rotate(-20 100 100)" className="opacity-90" />
            <ellipse cx="100" cy="100" rx="75" ry="20" fill="none" stroke="#0077ff" strokeWidth="2" transform="rotate(10 100 100)" className="opacity-70" />
          </svg>
        </div>
        <div className="relative z-10 w-1/2 h-1/2">
          <svg viewBox="0 0 100 100" className="w-full h-full">
            <circle cx="50" cy="50" r="48" fill="white" />
            <path d="M50 2 L65 25 L50 48 L35 25 Z M65 25 L95 35 L88 70 L65 60 L50 48 Z M35 25 L5 35 L12 70 L35 60 L50 48 Z M50 98 L70 75 L50 60 L30 75 Z" fill="#0f172a" />
          </svg>
        </div>
      </div>
      <div className="flex flex-col items-center -mt-4">
        <h1 className="text-white font-black italic tracking-tighter leading-none" style={{ fontSize: isLarge ? '56px' : '28px' }}>
          AURA
        </h1>
        <div className="flex items-center gap-3 w-full mt-2">
          <div className="h-[2px] flex-grow bg-white/20"></div>
          <span className="text-white font-black uppercase tracking-[0.6em]" style={{ fontSize: isLarge ? '14px' : '9px' }}>
            SPORT
          </span>
          <div className="h-[2px] flex-grow bg-white/20"></div>
        </div>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [state, setState] = useState<AppState>({
    news: [],
    scores: MOCK_SCORES,
    loading: true,
    error: null,
    selectedLanguage: 'all',
    aiSummary: null,
    selectedNews: null,
    activeView: 'home'
  });

  const loadData = useCallback(async (lang: Language | 'all') => {
    const newsData = await fetchNews(lang);
    setState(prev => ({ ...prev, news: newsData, loading: false }));
  }, []);

  useEffect(() => {
    if (state.activeView === 'home') {
      loadData(state.selectedLanguage);
    }
  }, [state.selectedLanguage, loadData, state.activeView]);

  const handleFilterChange = (filter: Language | 'all') => {
    setState(prev => ({ ...prev, selectedLanguage: filter, loading: true }));
  };

  const handleSelectNews = (item: NewsItem) => {
    setState(prev => ({ ...prev, selectedNews: item }));
  };

  const handleViewChange = (view: AppView) => {
    setState(prev => ({ ...prev, activeView: view }));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const breakingNews = state.news.find(n => n.isBreaking) || state.news[0];

  return (
    <div className="min-h-screen flex flex-col text-white">
      {state.selectedNews && (
        <NewsDetail 
          item={state.selectedNews} 
          onClose={() => setState(prev => ({ ...prev, selectedNews: null }))} 
        />
      )}

      <Ticker scores={state.scores} />
      <Header activeView={state.activeView} onViewChange={handleViewChange} />

      <main className="flex-grow container mx-auto px-4 py-10 max-w-6xl">
        {state.activeView === 'home' && (
          <>
            <FilterBar 
              currentFilter={state.selectedLanguage} 
              onFilterChange={handleFilterChange} 
            />

            {state.loading && state.news.length > 0 && (
              <div className="flex justify-center mb-6">
                <div className="flex items-center gap-3 px-4 py-1.5 bg-blue-600/10 border border-blue-500/20 rounded-full">
                  <span className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-ping"></span>
                  <span className="text-[9px] font-black text-blue-400 uppercase tracking-widest">Updating Live Pulse...</span>
                </div>
              </div>
            )}

            {!state.loading && breakingNews && (
              <div 
                onClick={() => handleSelectNews(breakingNews)}
                className="mb-20 relative rounded-[3.5rem] overflow-hidden shadow-[0_40px_120px_rgba(0,0,0,0.8)] group cursor-pointer border border-white/5"
              >
                <div className="absolute inset-0 bg-gradient-to-t from-[#030712] via-[#030712]/50 to-transparent z-10"></div>
                <img 
                  src={breakingNews.imageUrl} 
                  className="w-full h-[550px] md:h-[650px] object-cover transition-transform duration-[3s] group-hover:scale-105" 
                  alt="Breaking"
                />
                <div className="absolute bottom-0 right-0 p-8 md:p-20 z-20 max-w-4xl text-right">
                  <div className="flex items-center justify-end gap-3 mb-8">
                     <span className="bg-red-600 text-white text-[9px] font-black px-5 py-1.5 rounded-full uppercase tracking-[0.3em] shadow-lg shadow-red-600/30">
                       {breakingNews.language === Language.KURDISH ? 'هەواڵی بەپەلە' : 'تغطية عاجلة'}
                     </span>
                  </div>
                  <h2 className={`text-4xl md:text-7xl font-black text-white mb-10 leading-[1] tracking-tighter ${breakingNews.language === Language.KURDISH ? 'font-kurdish' : ''}`}>
                    {breakingNews.title}
                  </h2>
                  <button className="bg-white text-black px-14 py-6 rounded-3xl font-black text-xl transition-all hover:bg-blue-600 hover:text-white hover:scale-105 active:scale-95 shadow-2xl">
                    <span>{breakingNews.language === Language.KURDISH ? 'زیاتر بخوێنەوە' : 'عرض التفاصيل'}</span>
                  </button>
                </div>
              </div>
            )}

            {state.news.length > 0 && <GeminiSummary news={state.news} />}

            <LeagueSection />

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
              {state.loading && state.news.length === 0 ? (
                Array(6).fill(0).map((_, i) => <NewsSkeleton key={i} />)
              ) : (
                state.news.map(item => (
                  <NewsCard key={item.id} item={item} onSelect={handleSelectNews} />
                ))
              )}
            </div>
          </>
        )}

        {state.activeView === 'leagues' && (
          <div className="animate-in fade-in slide-in-from-bottom-8 duration-1000">
             <div className="mb-24 text-center">
                <span className="text-blue-500 font-black text-[10px] tracking-[0.5em] uppercase mb-4 block">Official Standings</span>
                <h1 className="text-6xl md:text-8xl font-black mb-8 italic tracking-tighter uppercase leading-none">LEAGUE <span className="text-blue-400">HUB</span></h1>
                <p className="text-gray-500 text-xl font-medium max-w-2xl mx-auto">تغطية ذكية لمراكز الصدارة في الدوريات المحلية بذكاء اصطناعي فائق.</p>
             </div>
             <LeagueSection />
          </div>
        )}

        {state.activeView === 'mercato' && <MercatoView onSelect={handleSelectNews} />}
      </main>

      <footer className="bg-gray-950 py-32 mt-40 border-t border-white/5 relative overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[500px] h-[500px] bg-blue-600/5 blur-[120px] rounded-full"></div>
        <div className="container mx-auto px-4 text-center relative z-10 flex flex-col items-center">
          
          {/* Footer Official Logo */}
          <div className="mb-16">
             <OfficialAuraLogo size="large" />
          </div>

          <p className="text-[10px] text-gray-700 uppercase tracking-[1em] font-black mb-8 opacity-40">AI Intelligence Hub</p>
          <div className="flex flex-col gap-2">
            <p className="text-[8px] text-gray-800 font-bold uppercase tracking-widest">© 2025 ELITE FOOTBALL MEDIA GROUP</p>
            <p className="text-[7px] text-blue-500/40 font-black uppercase tracking-[0.5em]">Powered by Aura Sport Engine</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
